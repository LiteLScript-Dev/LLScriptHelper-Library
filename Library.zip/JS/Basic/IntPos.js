/**
 * 🎯 坐标对象
多用来表示方块坐标等用整数表示的位置
 */ 
class IntPos {
  
/**
 * x 坐标
 * @type number
 */ 
 x;
/**
 * y 坐标
 * @type number
 */ 
 y;
/**
 * z 坐标
 * @type number
 */ 
 z;
/**
 * 维度文字名
 * @type string
 */ 
 dim;
/**
 * 维度ID
 * @type number
 */ 
 dimid;
  
  
  



}
