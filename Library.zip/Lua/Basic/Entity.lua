---@class Entity  
 Entity = {}
