---@class IntPos 🎯 坐标对象
多用来表示方块坐标等用整数表示的位置 
---@field x number number
---@field y number number
---@field z number number
---@field dim string string
---@field dimid number number
 IntPos = {}
