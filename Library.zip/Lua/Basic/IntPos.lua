---@class IntPos 🎯 坐标对象
多用来表示方块坐标等用整数表示的位置 
---@field x Integer Integer
---@field y Integer Integer
---@field z Integer Integer
---@field dim String String
---@field dimid Integer Integer
 IntPos = {}
