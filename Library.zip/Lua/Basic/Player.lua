---\n---@class Player 
 Player = {}