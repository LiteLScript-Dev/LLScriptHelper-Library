---@class ObjectRuncmdEx mc.runcmdEx的返回结果 
---@field success boolean boolean
---@field output string string
 ObjectRuncmdEx = {}
