---@class ObjectRuncmdEx mc.runcmdEx的返回结果 
---@field success Boolean Boolean
---@field output String String
 ObjectRuncmdEx = {}
