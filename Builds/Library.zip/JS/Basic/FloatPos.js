/**
 * 🎯 坐标对象
多用来表示实体坐标等用无法用整数表示的位置
 */ 
class FloatPos {
  
/**
 * x 坐标
 * @type Float
 */ 
 x;
/**
 * y 坐标
 * @type Float
 */ 
 y;
/**
 * z 坐标
 * @type Float
 */ 
 z;
/**
 * 维度文字名
 * @type String
 */ 
 dim;
/**
 * 维度ID
 * @type Integer
 */ 
 dimid;
  
  
  



}
