
/// <reference path="./Basic/Block.js" />
/// <reference path="./Basic/Entity.js" />
/// <reference path="./Basic/FloatPos.js" />
/// <reference path="./Basic/IntPos.js" />
/// <reference path="./Basic/Item.js" />
/// <reference path="./Basic/mc.js" />
/// <reference path="./Basic/Player.js" />
/// <reference path="./Global/Global.js" />
/// <reference path="./Object/ObjectRuncmdEx.js" />