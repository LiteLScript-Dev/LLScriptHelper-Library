---float\n---@class Float 
 Float = {}