---float
---@class Float 
 Float = {}