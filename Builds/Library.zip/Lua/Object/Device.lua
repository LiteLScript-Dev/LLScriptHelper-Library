---获取一个设备信息对象\n---@class Device 
---@field ip String String
---@field avgPing Integer Integer
---@field avgPacketLoss Float Float
---@field os String String
---@field clientId String String
 Device = {}