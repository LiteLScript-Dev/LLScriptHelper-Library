---\n---@class Entity 
 Entity = {}