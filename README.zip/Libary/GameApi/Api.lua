---计分板新增计分项
---@param name string 计分项名称
---@return boolean 是否设置成功
function mc.newScoreBoard(name) end

---计分板移除计分项
---@param name string 计分项名称
---@return boolean 是否设置成功
function mc.removeScoreBoard(name) end